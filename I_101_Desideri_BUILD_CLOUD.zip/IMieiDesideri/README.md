# I 101 Desideri — progetto Android

Progetto base Android nativo in Kotlin + Jetpack Compose.

## Funzioni incluse
- Bozza con massimo 150 desideri.
- Controlli di base: formula «Io voglio», massimo 14 parole, alcune negazioni comuni, duplicati.
- Selezione manuale fino a 101 desideri.
- Schermata di rilettura quotidiana con caselle per annotare i progressi.
- Salvataggio locale sul dispositivo tramite SharedPreferences; nessun account o server.

## Aprire e generare l'app
1. Installa Android Studio (versione recente).
2. Apri la cartella `IMieiDesideri`.
3. Attendi la sincronizzazione Gradle.
4. Collega un dispositivo Android o avvia un emulatore.
5. Premi Run.

Per creare un APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Nota sul metodo
Le regole riportate nell'app sono una guida ispirata alle descrizioni pubbliche dell'esercizio dei 101 desideri attribuito a Igor Sibaldi. Non è un'app ufficiale né affiliata all'autore. I controlli automatici sono orientativi: non possono comprendere perfettamente il significato di ogni frase.
