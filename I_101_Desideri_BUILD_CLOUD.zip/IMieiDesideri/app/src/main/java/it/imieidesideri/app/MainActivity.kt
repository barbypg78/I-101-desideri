package it.imieidesideri.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

private val ink = Color(0xFF27352F)
private val gold = Color(0xFFB28A50)
private val cream = Color(0xFFFAF7F0)
private const val PREFS = "wishes"
private const val MAX_DRAFTS = 150
private const val MAX_FINAL = 101

data class Wish(
    val text: String,
    val note: String = "",
    val created: String = todayKey(),
    val done: Boolean = false,
    val completed: String = ""
)
private fun todayKey() = SimpleDateFormat("yyyy-MM-dd", Locale.ITALY).format(Date())
private fun prettyDate(key: String) = try {
    SimpleDateFormat("dd MMMM yyyy", Locale.ITALY).format(SimpleDateFormat("yyyy-MM-dd", Locale.ITALY).parse(key)!!)
} catch (_: Exception) { key }

class MainActivity : ComponentActivity() {
    private val askNotification = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotification.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { WishesApp(this) }
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("daily_wishes", "Promemoria desideri", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

class DailyReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminder", false)) return
        val notification = Notification.Builder(context, "daily_wishes")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Un momento per i tuoi desideri")
            .setContentText("Dedica qualche minuto alla rilettura quotidiana.")
            .setAutoCancel(true)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(101, notification)
    }
}

private fun loadList(context: Context, key: String): MutableList<Wish> {
    val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        MutableList(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Wish(o.getString("text"), o.optString("note"), o.optString("created", todayKey()),
                o.optBoolean("done"), o.optString("completed"))
        }
    } catch (_: Exception) { mutableListOf() }
}
private fun saveList(context: Context, key: String, list: List<Wish>) {
    val arr = JSONArray()
    list.forEach { w ->
        arr.put(JSONObject().put("text", w.text).put("note", w.note).put("created", w.created)
            .put("done", w.done).put("completed", w.completed))
    }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(key, arr.toString()).apply()
}
private fun loadNotes(context: Context): MutableMap<String, String> {
    val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("daily_notes", "{}") ?: "{}"
    val obj = JSONObject(raw)
    return mutableMapOf<String, String>().apply { obj.keys().forEach { put(it, obj.getString(it)) } }
}
private fun saveNotes(context: Context, notes: Map<String, String>) {
    val obj = JSONObject()
    notes.forEach { (k, v) -> obj.put(k, v) }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("daily_notes", obj.toString()).apply()
}
private fun wordCount(s: String) = s.trim().split(Regex("\\s+")).count { it.isNotBlank() }
private val forbidden = listOf(" non ", " niente ", " nessuno ", " nessuna ", " nulla ", " mai ")
private fun scheduleReminder(context: Context, enabled: Boolean) {
    val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    prefs.edit().putBoolean("reminder", enabled).apply()
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, DailyReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(context, 101, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    if (!enabled) alarm.cancel(pending) else {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 20); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
    }
}
private fun hashPin(pin: String) = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString("") { "%02x".format(it) }

private fun dailyQuote(): String {
    val quotes = listOf(
        "Un desiderio prende forma quando trovi il coraggio di nominarlo.",
        "Ogni piccolo passo rende più vicino ciò che immagini.",
        "Concediti di desiderare in grande e di cominciare da oggi.",
        "La chiarezza è il primo gesto concreto verso ciò che vuoi.",
        "Ascolta ciò che conta davvero per te, poi dagli spazio.",
        "Un'intenzione sincera può diventare una scelta quotidiana.",
        "Non serve avere già tutta la strada: basta scegliere il prossimo passo.",
        "Dai attenzione ai desideri che parlano con la tua voce.",
        "La tua vita cambia anche attraverso le piccole decisioni di ogni giorno.",
        "Scrivi ciò che vuoi con semplicità, presenza e fiducia.",
        "Ogni giorno è un'occasione per avvicinarti alla persona che vuoi diventare.",
        "Un desiderio merita ascolto, cura e un primo gesto concreto."
    )
    val index = Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % quotes.size
    return quotes[index]
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WishesApp(context: Context) {
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var drafts by remember { mutableStateOf(loadList(context, "drafts")) }
    var chosen by remember { mutableStateOf(loadList(context, "chosen")) }
    var achieved by remember { mutableStateOf(loadList(context, "achieved")) }
    var notes by remember { mutableStateOf(loadNotes(context)) }
    var tab by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf("") }
    var showHelp by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var noteInput by remember { mutableStateOf(notes[todayKey()] ?: "") }
    var pinInput by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var showPinDialog by remember { mutableStateOf(false) }
    var unlockInput by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(prefs.getString("pin_hash", null) == null) }
    var showUnlockError by remember { mutableStateOf(false) }
    var remind by remember { mutableStateOf(prefs.getBoolean("reminder", false)) }
    var showNoteHistory by remember { mutableStateOf(false) }
    val today = todayKey()

    fun saveDrafts(v: List<Wish>) { drafts = v.toMutableList(); saveList(context, "drafts", v) }
    fun saveChosen(v: List<Wish>) { chosen = v.toMutableList(); saveList(context, "chosen", v) }
    fun saveAchieved(v: List<Wish>) { achieved = v.toMutableList(); saveList(context, "achieved", v) }
    fun saveDailyNotes(v: Map<String, String>) { notes = v.toMutableMap(); saveNotes(context, v) }

    MaterialTheme(colorScheme = lightColorScheme(primary = ink, secondary = gold, background = cream, surface = Color.White)) {
        if (!unlocked) {
            Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Lock, null, tint = gold, modifier = Modifier.size(48.dp))
                Text("I 101 Desideri", style = MaterialTheme.typography.headlineMedium, color = ink, fontWeight = FontWeight.Bold)
                Text("Inserisci il PIN per aprire il tuo diario", color = Color.Gray)
                OutlinedTextField(value = unlockInput, onValueChange = { unlockInput = it.filter(Char::isDigit).take(6) },
                    label = { Text("PIN") }, modifier = Modifier.fillMaxWidth())
                if (showUnlockError) Text("PIN non corretto", color = Color.Red)
                Button(onClick = {
                    if (hashPin(unlockInput) == prefs.getString("pin_hash", "")) { unlocked = true; unlockInput = ""; showUnlockError = false }
                    else showUnlockError = true
                }, modifier = Modifier.fillMaxWidth()) { Text("Sblocca") }
            }
        } else Scaffold(
            containerColor = cream,
            topBar = {
                TopAppBar(title = { Column {
                    Text("I 101 Desideri", fontWeight = FontWeight.Bold, color = ink)
                    Text("Il tuo quaderno personale", style = MaterialTheme.typography.labelSmall, color = gold)
                } }, actions = {
                    IconButton(onClick = { showHelp = true }) { Icon(Icons.Default.Info, "Regole") }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Impostazioni") }
                }, colors = TopAppBarDefaults.topAppBarColors(containerColor = cream))
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Edit, null) }, label = { Text("Scrivi") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Star, null) }, label = { Text("I 101") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.MenuBook, null) }, label = { Text("Diario") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.EmojiEvents, null) }, label = { Text("Realizzati") })
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp)) {
                AnimatedVisibility(
                    visible = tab == 0,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut()
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEDE3D2)),
                        shape = MaterialTheme.shapes.extraLarge
                    ) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = gold)
                                Spacer(Modifier.width(7.dp))
                                Text("IL TUO SPAZIO, LA TUA POSSIBILITÀ", color = Color(0xFF80623C),
                                    style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("I 101 Desideri", style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold, color = ink)
                            Text("Un quaderno per dare voce a ciò che vuoi realizzare.",
                                style = MaterialTheme.typography.bodyMedium, color = Color(0xFF59645D))
                            Divider(Modifier.padding(vertical = 12.dp), color = Color(0xFFD8C8AF))
                            Text("LA FRASE DI OGGI", color = Color(0xFF80623C),
                                style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text("“${dailyQuote()}”", style = MaterialTheme.typography.bodyLarge,
                                color = ink, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                when (tab) {
                    0 -> {
                        Text("PRIMA FASE", color = gold, style = MaterialTheme.typography.labelLarge)
                        Text("Raccogli 150 desideri", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = ink)
                        Text("${drafts.size} di 150 · ${chosen.size} selezionati per la lista finale", color = Color.Gray)
                        LinearProgressIndicator(progress = { (drafts.size / 150f).coerceIn(0f,1f) }, modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp), color = gold)
                        OutlinedTextField(value = input, onValueChange = { input = it; feedback = "" },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Io voglio…") },
                            placeholder = { Text("Io voglio visitare il Giappone") }, minLines = 2,
                            supportingText = { Text("${wordCount(input)} / 14 parole") })
                        Button(onClick = {
                            val t = input.trim()
                            val lower = " ${t.lowercase(Locale.ITALIAN)} "
                            val errors = mutableListOf<String>()
                            if (!t.startsWith("Io voglio", true)) errors += "Inizia con «Io voglio»."
                            if (wordCount(t) > 14) errors += "Massimo 14 parole."
                            if (forbidden.any { lower.contains(it) }) errors += "Prova a formulare in positivo."
                            if (t.length < 10) errors += "Rendi il desiderio più specifico."
                            if (drafts.any { it.text.equals(t, true) } || chosen.any { it.text.equals(t, true) }) errors += "Desiderio già presente."
                            if (drafts.size >= MAX_DRAFTS) errors += "Hai raggiunto i 150 desideri."
                            if (errors.isEmpty()) { saveDrafts(drafts + Wish(t)); input = ""; feedback = "Desiderio aggiunto al quaderno." }
                            else feedback = errors.joinToString(" ")
                        }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp)) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Aggiungi desiderio")
                        }
                        if (feedback.isNotBlank()) Text(feedback, color = if (feedback.startsWith("Desiderio aggiunto")) ink else Color(0xFF9B493B), modifier = Modifier.padding(7.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Le tue idee", fontWeight = FontWeight.Bold, color = ink)
                            Text("${chosen.size}/101 nella lista finale", color = gold)
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            itemsIndexed(drafts, key = { _, w -> w.text }) { index, w ->
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${index+1}. ${w.text}", Modifier.weight(1f), color = ink)
                                        if (chosen.none { it.text == w.text } && chosen.size < MAX_FINAL) IconButton(onClick = { saveChosen(chosen + w) }) { Icon(Icons.Default.StarBorder, "Seleziona", tint = gold) }
                                        else if (chosen.any { it.text == w.text }) Icon(Icons.Default.CheckCircle, "Selezionato", tint = gold, modifier = Modifier.padding(8.dp))
                                        IconButton(onClick = { saveDrafts(drafts.filterNot { it.text == w.text }); saveChosen(chosen.filterNot { it.text == w.text }) }) { Icon(Icons.Default.DeleteOutline, "Elimina") }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        Text("LA TUA LISTA", color = gold, style = MaterialTheme.typography.labelLarge)
                        Text("I 101 desideri", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = ink)
                        Text("${chosen.size} selezionati · puoi arrivare fino a 101", color = Color.Gray)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            itemsIndexed(chosen, key = { _, w -> w.text }) { i, w ->
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${i+1}. ${w.text}", Modifier.weight(1f), color = ink)
                                        IconButton(onClick = {
                                            saveChosen(chosen.filterNot { it.text == w.text })
                                            if (drafts.none { it.text == w.text }) saveDrafts(drafts + w)
                                        }) { Icon(Icons.Default.RemoveCircleOutline, "Rimuovi dalla lista") }
                                        IconButton(onClick = {
                                            saveChosen(chosen.filterNot { it.text == w.text })
                                            saveAchieved(achieved + w.copy(done = true, completed = today))
                                            saveDrafts(drafts.filterNot { it.text == w.text })
                                        }) { Icon(Icons.Default.EmojiEvents, "Segna come realizzato", tint = gold) }
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        Text("IL TUO SPAZIO QUOTIDIANO", color = gold, style = MaterialTheme.typography.labelLarge)
                        Text("Diario e rilettura", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = ink)
                        Text(prettyDate(today), color = Color.Gray)
                        Spacer(Modifier.height(8.dp))
                        Text("Un pensiero, un passo concreto, un'intuizione di oggi", color = ink)
                        OutlinedTextField(value = noteInput, onValueChange = { noteInput = it },
                            modifier = Modifier.fillMaxWidth(), minLines = 3, label = { Text("Le mie note di oggi") })
                        Button(onClick = { saveDailyNotes(notes + (today to noteInput)); feedback = "Diario salvato." }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Salva la pagina di oggi")
                        }
                        if (feedback == "Diario salvato.") Text(feedback, color = ink)
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Rilettura dei 101", fontWeight = FontWeight.Bold, color = ink)
                            Text("${chosen.count { it.done }} spuntati", color = gold)
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.weight(1f)) {
                            itemsIndexed(chosen, key = { _, w -> w.text }) { _, w ->
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = w.done, onCheckedChange = { checked ->
                                            saveChosen(chosen.map { if (it.text == w.text) it.copy(done = checked) else it })
                                        })
                                        Text(w.text, Modifier.weight(1f), color = ink)
                                    }
                                }
                            }
                        }
                        OutlinedButton(onClick = { showNoteHistory = !showNoteHistory }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text(if (showNoteHistory) "Nascondi calendario diario" else "Apri calendario del diario")
                        }
                        if (showNoteHistory) {
                            Text("Pagine salvate", fontWeight = FontWeight.Bold, color = ink)
                            notes.toSortedMap(compareByDescending { it }).forEach { (date, note) ->
                                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Column(Modifier.padding(10.dp)) { Text(prettyDate(date), color = gold, fontWeight = FontWeight.Bold); Text(note.ifBlank { "Nessuna nota" }, color = ink) }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("I TUOI TRAGUARDI", color = gold, style = MaterialTheme.typography.labelLarge)
                        Text("Desideri realizzati", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = ink)
                        Text("${achieved.size} desideri celebrati", color = Color.Gray)
                        if (achieved.isEmpty()) {
                            Spacer(Modifier.height(20.dp))
                            Text("Qui compariranno i desideri che segnerai come realizzati dalla lista dei 101.", color = ink)
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            itemsIndexed(achieved, key = { _, w -> w.text }) { i, w ->
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.EmojiEvents, null, tint = gold)
                                            Spacer(Modifier.width(8.dp))
                                            Text("Traguardo ${i+1}", color = gold, fontWeight = FontWeight.Bold)
                                            Spacer(Modifier.weight(1f))
                                            Text(prettyDate(w.completed), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                        }
                                        Text(w.text, color = ink)
                                        TextButton(onClick = {
                                            saveAchieved(achieved.filterNot { it.text == w.text })
                                            saveChosen(chosen + w.copy(done = false, completed = ""))
                                        }) { Text("Ripristina nella lista") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showHelp) AlertDialog(onDismissRequest = { showHelp = false }, title = { Text("Regole di scrittura") }, text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                listOf("Inizia con «Io voglio».", "Formula in positivo, evitando negazioni.",
                    "Massimo 14 parole, compresa la formula iniziale.", "Sii concreto, preciso e verificabile.",
                    "Scrivi desideri che riguardano te.", "Evita paragoni, ripetizioni e desideri seriali.",
                    "Concentrati sul risultato, non sui mezzi o sul denaro.",
                    "Le verifiche automatiche sono orientative e non capiscono sempre il contesto.")
                    .forEachIndexed { i, s -> Text("${i+1}. $s", modifier = Modifier.padding(vertical = 4.dp)) }
                Text("Guida ispirata alle descrizioni pubbliche dell'esercizio; app non ufficiale e non affiliata all'autore.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        }, confirmButton = { TextButton(onClick = { showHelp = false }) { Text("Ho capito") } })

        if (showSettings) AlertDialog(onDismissRequest = { showSettings = false },
            title = { Text("Impostazioni e privacy") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Promemoria quotidiano", fontWeight = FontWeight.Bold)
                            Text("Ogni giorno alle 20:00", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        Switch(checked = remind, onCheckedChange = {
                            remind = it; scheduleReminder(context, it)
                        })
                    }
                    Divider()
                    Text("Protezione con PIN", fontWeight = FontWeight.Bold)
                    OutlinedButton(onClick = { showPinDialog = true }) { Text(if (prefs.getString("pin_hash", null) == null) "Imposta un PIN" else "Cambia PIN") }
                    if (prefs.getString("pin_hash", null) != null) {
                        TextButton(onClick = { prefs.edit().remove("pin_hash").apply(); unlocked = true }) { Text("Rimuovi PIN") }
                    }
                    Text("I dati restano salvati localmente sul dispositivo. Il PIN è una protezione semplice dell'app, non una cifratura dei dati.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Chiudi") } })
        if (showPinDialog) AlertDialog(onDismissRequest = { showPinDialog = false; pinInput = ""; pinConfirm = "" },
            title = { Text("Imposta un PIN") },
            text = {
                Column {
                    OutlinedTextField(value = pinInput, onValueChange = { pinInput = it.filter(Char::isDigit).take(6) }, label = { Text("Nuovo PIN (4–6 cifre)") })
                    OutlinedTextField(value = pinConfirm, onValueChange = { pinConfirm = it.filter(Char::isDigit).take(6) }, label = { Text("Ripeti PIN") })
                    if (pinInput.isNotEmpty() && pinConfirm.isNotEmpty() && pinInput != pinConfirm) Text("I PIN non coincidono", color = Color.Red)
                }
            },
            confirmButton = { TextButton(onClick = {
                if (pinInput.length in 4..6 && pinInput == pinConfirm) {
                    prefs.edit().putString("pin_hash", hashPin(pinInput)).apply()
                    showPinDialog = false; pinInput = ""; pinConfirm = ""
                }
            }) { Text("Salva") } },
            dismissButton = { TextButton(onClick = { showPinDialog = false }) { Text("Annulla") } })
    }
}
